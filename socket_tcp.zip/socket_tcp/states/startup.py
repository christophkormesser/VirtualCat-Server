from client_tools  import send_command
from utils.wrap_stats import wrap_stats
import socket


def startup(s: socket.socket):

    response = None

    while(response != "ACK\r\n"):
        

        response = send_command(s, "1,0,0,0").decode("utf-8")
        print(f"Startup Response: {response}")

        


