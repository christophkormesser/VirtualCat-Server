from client_tools import establish_connection
from states.startup import startup
from states.moodsetter import set_mood
from models import OledInputModel



def main():

    # connects to oled nucleo and returns socket
    print("Establishing connection to OLED Nucleo...")
    socket_oled = establish_connection("192.168.0.1", 8500)
    socket_oled.settimeout(20.0)
    print("Connection established:", socket_oled)

    # connects to proximity nucleo and returns socket
    # print("Establishing connection to Proximity Nucleo...")
    # socket_proximity = establish_connection("192.168.0.5", 8500)
    # print("Connection established:", socket_proximity)

    stats = OledInputModel(game_mode=0,rounds=0,wins=0,losses=0)
       

    # starts welcome screen
    startup(socket_oled)

    while True:
        set_mood(socket_oled, stats)


    

    # game loop

main()