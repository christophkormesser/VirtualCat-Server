import netifaces as ni

def get_ip(interface='en0'):
    try:
        ip_address = ni.ifaddresses(interface)[ni.AF_INET][0]['addr']
    except Exception as e:
        print("Couldn't get the IP address of the specified interface. Error: ", e)
        ip_address = None
    return ip_address
